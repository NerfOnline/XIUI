# Hotbar Future Features

Ideas gathered from XIVHotbar and XIVHotbar2 for future implementation.

---

## Action Execution Feedback

Visual confirmation when an action is triggered.

### Flash Animation
- Semi-transparent white overlay flashes on slot
- Opacity starts at ~150, decrements rapidly (30 per frame)
- Duration: ~5 frames (very quick)
- Uses existing animation.lua easing system

### Border Highlight (Alternative)
- Golden border pulse around activated slot
- Quick scale-up then return (1.0 → 1.1 → 1.0)

### Configuration
```lua
gConfig.hotbarGlobal.showActionFeedback    -- true/false
gConfig.hotbarGlobal.feedbackStyle         -- 'flash', 'border', 'both'
gConfig.hotbarGlobal.feedbackOpacity       -- 0-255
gConfig.hotbarGlobal.feedbackSpeed         -- frames to fade
```

---

## Resource & State Awareness

Show when actions are unavailable due to resources or status effects.

### MP/TP Cost Checking
- Insufficient MP: Slot dimmed + optional red tint
- Insufficient TP: Slot dimmed (weaponskills need 1000+ TP)
- Check performed per-frame for active slots only
- Cost text color change (white → red when insufficient)

### Status Effect Awareness
Disable actions when affected by:
- Silence/Mute → Spells (ma) disabled
- Amnesia → Abilities (ja) and Weaponskills (ws) disabled
- Sleep/Stun/Terror/Petrify → All actions disabled

Uses existing debuffhandler.lua for status tracking.
Visual: Heavy dimming + optional "X" overlay.

### Performance Notes
- Cache player vitals (MP/TP) per-frame, not per-slot
- Cache status effects, update only on buff/debuff change
- Use hash table for O(1) status lookups
- Only check slots with actions (skip empty)

---

## Ability & Weaponskill Icons

Currently only spells and items have icons.

### Asset Pipeline
- Extract ability icons from game DAT files
- Extract weaponskill icons from game resources
- Store in `assets/hotbar/abilities/` and `assets/hotbar/weaponskills/`
- Naming: `[abilityId].png`, `[wsId].png`
- Fallback: Generic icons (gear.png, sword.png, etc.)

### Icon Database
- Create ability ID → icon mapping
- Create weaponskill ID → icon mapping
- Use Ashita's resource manager where possible
- Cache loaded textures per session

---

## Enhanced Hover Tooltips

XIVHotbar shows detailed spell info on hover.

### Spell Information
- Spell Name (yellow)
- MP Cost (green)
- Cast Time
- Recast Time
- Range (Self, or distance in yalms)
- Target Type (Single, AoE, Self)
- Element (optional icon)

### Ability Information
- Ability Name
- Recast Time
- Duration (if applicable)
- Range
- Brief description

### Weaponskill Information
- WS Name
- TP Range (1000-3000)
- Skillchain Properties
- Stat Modifiers (STR/DEX/etc weights)
- fTP values (optional, for advanced users)

### Configuration
```lua
gConfig.hotbarGlobal.showTooltips          -- true/false
gConfig.hotbarGlobal.tooltipDelay          -- ms before showing (default 200)
gConfig.hotbarGlobal.tooltipShowCost       -- show MP/TP cost
gConfig.hotbarGlobal.tooltipShowRecast     -- show recast time
gConfig.hotbarGlobal.tooltipShowRange      -- show range info
```

---

## Level Sync Awareness

XIVHotbar2's standout feature - auto-hides unavailable spells/abilities when level-synced.

### Level Detection
- Detect current effective level (sync vs actual)
- Track via party buff detection or memory read
- Compare action requirements against effective level
- Update on level sync start/end events

### Visual Handling Options
- Option A: Hide unavailable slots entirely
- Option B: Dim + "level lock" icon overlay
- Option C: Show but prevent execution

### Required Data
- Spell level requirements (horizonspells.lua already has this)
- Ability level requirements (need to add)
- Weaponskill level requirements (need to add)
- Job restrictions

---

## Tiered Spell Slots

Auto-swap spell tiers (Cure → Cure II → Cure III) based on level.

### Tier Definition System
```lua
spellTiers = {
    ['Cure'] = { 'Cure', 'Cure II', 'Cure III', 'Cure IV', 'Cure V', 'Cure VI' },
    ['Fire'] = { 'Fire', 'Fire II', 'Fire III', 'Fire IV', 'Fire V', 'Fire VI' },
    ['Dia'] = { 'Dia', 'Dia II', 'Dia III' },
    -- etc.
}
```

### Auto-Selection Logic
- For each tiered slot, iterate tiers from highest to lowest
- Check: Is spell learned? Is level requirement met?
- Display highest available tier
- Update on: level change, spell learned, job change
- Visual indicator showing tier upgrades available (optional)

### Configuration
```lua
gConfig.hotbarGlobal.enableTieredSpells    -- true/false
gConfig.hotbarGlobal.showTierIndicator     -- show "II", "III" badge
```

---

## Battle/Field Environment Toggle

Two hotbar sets: one for combat, one for exploration/crafting.

### Implementation
- Duplicate action storage: `slotActions[jobId]['battle']` and `slotActions[jobId]['field']`
- Toggle via keybind (default: backslash)
- Visual indicator showing current mode
- Separate drag-drop and macro palette per environment

### Visual Toggle
- Small text indicator: "Battle" / "Field"
- Color coding: Red/Gold for battle, Blue/Green for field
- Position: Corner of first hotbar
- Clickable to toggle

---

## Unlearned Spell Visualization

XIVHotbar2 shows unlearned spells as dimmed with a scroll overlay.

### Visual Treatment
- Heavy dimming (20-30% opacity)
- Scroll/book icon overlay
- Tooltip shows "Not yet learned" + level requirement
- Non-clickable (or shows error message on click)

### Use Cases
- Planning hotbar layout before learning spells
- Visual progression tracking
- Prevents "missing spell" confusion
- Works with level sync (shows what's locked)

---

## Priority Order

| Feature | Impact | Complexity |
|---------|--------|------------|
| Action Feedback Flash | High | Low |
| MP/TP Cost Checking | High | Medium |
| Status Effect Awareness | High | Medium |
| Ability/WS Icons | Medium | Medium |
| Enhanced Tooltips | Medium | Low-Med |
| Level Sync Awareness | Medium | High |
| Tiered Spell Slots | Medium | High |
| Battle/Field Toggle | Low-Med | Low |
| Unlearned Visualization | Low | Low |
