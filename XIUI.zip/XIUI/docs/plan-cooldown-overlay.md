# Cooldown Overlay Implementation Plan

## Goal

Add visual cooldown indicators to hotbar slots showing when spells/abilities are on recast timer.

**Visual Result:**
- Dark overlay covers the icon when on cooldown
- Timer text shows remaining time (e.g., "2:30", "45s", "3.2")
- Icon dims while on cooldown
- Returns to normal when ready

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     RENDER LAYERS                           │
│  (Ashita renders primitives in creation order)              │
├─────────────────────────────────────────────────────────────┤
│  1. Window background      (windowBg primitives)            │
│  2. Slot backgrounds       (slotPrims)                      │
│  3. Action icons           (iconPrims)         ← NEW        │
│  4. Cooldown overlays      (cooldownPrims)     ← NEW        │
│  5. GDI fonts              (keybind, label, timer fonts)    │
│  6. ImGui elements         (hover effects, tooltips)        │
└─────────────────────────────────────────────────────────────┘
```

---

## File Changes Overview

| File | Action | Purpose |
|------|--------|---------|
| `data.lua` | Modify | Add primitive/font storage tables |
| `init.lua` | Modify | Create primitives and fonts in correct order |
| `display.lua` | Modify | Render icons via primitives, add cooldown logic |
| `textures.lua` | Modify | Store file paths for primitive texture loading |
| `actions.lua` | Modify | Return texture paths and action metadata |
| `recast.lua` | **Create** | Spell/ability recast tracking |
| `actiondb.lua` | **Create** | Action name → ID mapping |

---

## Step 1: Update data.lua

Add storage for new primitives and fonts.

### Location: After line 42 (after `M.labelFonts = {}`)

```lua
-- Icon primitives (per bar, per slot)
-- Renders action icons as primitives instead of ImGui
M.iconPrims = {};

-- Cooldown overlay primitives (per bar, per slot)
-- Dark overlay shown when action is on cooldown
M.cooldownPrims = {};

-- Cooldown timer fonts (per bar, per slot)
-- Shows remaining recast time (e.g., "2:30", "45s")
M.timerFonts = {};
```

### Location: In M.Cleanup() function (around line 540)

Add cleanup for new tables:
```lua
M.iconPrims = {};
M.cooldownPrims = {};
M.timerFonts = {};
```

---

## Step 2: Update textures.lua

Modify texture cache to store file paths (primitives need paths, not D3D pointers).

### Change LoadTextureFromPath return (around line 24)

```lua
-- Change from:
return textures;

-- To:
return {
    image = textures.image,
    path = filePath,
    width = 40,
    height = 40,
};
```

### Update cache storage (around line 63)

```lua
-- Store with path information
local textureData = LoadTextureFromPath(fullPath);
if textureData then
    self.Cache[file] = textureData;
    self.Cache[key] = textureData;
end
```

### Add path getter function (after Get function)

```lua
-- Get texture path by key (for primitive rendering)
textures.GetPath = function(self, key)
    if not self.Cache then return nil; end
    local entry = self.Cache[key];
    if entry and entry.path then
        return entry.path;
    end
    return nil;
end
```

---

## Step 3: Create recast.lua

New module for tracking spell and ability cooldowns.

### File: modules/hotbar/recast.lua

```lua
--[[
* XIUI hotbar - Recast Tracking Module
* Tracks spell and ability cooldowns via Ashita memory
]]--

local abilityRecast = require('libs.abilityrecast');

local M = {};

-- Cached spell recasts (refreshed once per frame)
-- Key: spellId, Value: remaining seconds
M.spellRecasts = {};

-- Frame tracking to prevent multiple updates per frame
M.lastUpdateTime = 0;

-- Update all spell recasts (call once per frame in DrawWindow)
function M.Update()
    local currentTime = os.clock();
    -- Only update every 0.05 seconds (20 times per second)
    if currentTime - M.lastUpdateTime < 0.05 then
        return;
    end
    M.lastUpdateTime = currentTime;

    -- Get spell recasts from Ashita memory
    local recastMgr = AshitaCore:GetMemoryManager():GetRecast();
    if not recastMgr then return; end

    M.spellRecasts = {};

    -- Scan spell recast timers (0-1024 covers all spells)
    for spellId = 0, 1024 do
        local timer = recastMgr:GetSpellTimer(spellId);
        if timer and timer > 0 then
            -- Timer is in 1/60th seconds, convert to seconds
            M.spellRecasts[spellId] = timer / 60;
        end
    end
end

-- Get spell recast by ID
-- Returns: remaining seconds, or 0 if ready
function M.GetSpellRecast(spellId)
    if not spellId then return 0; end
    return M.spellRecasts[spellId] or 0;
end

-- Get ability recast by ability ID
-- Uses abilityrecast.lua which scans memory slots
-- Returns: remaining seconds, or 0 if ready
function M.GetAbilityRecast(abilityId)
    if not abilityId then return 0; end
    return abilityRecast.GetAbilityRecastByAbilityId(abilityId);
end

-- Format recast time for display
-- Returns: formatted string or nil if ready
function M.FormatRecast(seconds)
    if not seconds or seconds <= 0 then
        return nil;
    end

    if seconds >= 60 then
        -- Show as M:SS for times >= 1 minute
        local mins = math.floor(seconds / 60);
        local secs = math.floor(seconds % 60);
        return string.format('%d:%02d', mins, secs);
    elseif seconds >= 10 then
        -- Show as whole seconds for 10-59s
        return string.format('%ds', math.floor(seconds));
    else
        -- Show with decimal for < 10s
        return string.format('%.1f', seconds);
    end
end

-- Get recast for any action type
-- Returns: remainingSeconds, formattedText
function M.GetActionRecast(actionType, spellId, abilityId)
    local remaining = 0;

    if actionType == 'ma' and spellId then
        remaining = M.GetSpellRecast(spellId);
    elseif actionType == 'ja' and abilityId then
        remaining = M.GetAbilityRecast(abilityId);
    elseif actionType == 'pet' and abilityId then
        remaining = M.GetAbilityRecast(abilityId);
    end
    -- Note: 'ws' (weaponskills) don't have individual recasts

    return remaining, M.FormatRecast(remaining);
end

return M;
```

---

## Step 4: Create actiondb.lua

Maps action names to IDs for recast lookup.

### File: modules/hotbar/actiondb.lua

```lua
--[[
* XIUI hotbar - Action Database
* Maps action names to spell/ability IDs
]]--

local M = {};

-- Lookup tables (built on first use)
M.spellNameToId = nil;
M.abilityNameToId = nil;

-- Build spell name lookup table
local function BuildSpellLookup()
    if M.spellNameToId then return; end

    M.spellNameToId = {};
    local resourceMgr = AshitaCore:GetResourceManager();

    for id = 0, 1024 do
        local spell = resourceMgr:GetSpellById(id);
        if spell and spell.Name and spell.Name[1] then
            local name = spell.Name[1]:lower();
            M.spellNameToId[name] = id;
        end
    end
end

-- Build ability name lookup table
local function BuildAbilityLookup()
    if M.abilityNameToId then return; end

    M.abilityNameToId = {};
    local resourceMgr = AshitaCore:GetResourceManager();

    for id = 0, 1024 do
        local ability = resourceMgr:GetAbilityById(id);
        if ability and ability.Name and ability.Name[1] then
            local name = ability.Name[1]:lower();
            M.abilityNameToId[name] = id;
        end
    end
end

-- Get spell ID by name
function M.GetSpellId(spellName)
    if not spellName then return nil; end
    BuildSpellLookup();
    return M.spellNameToId[spellName:lower()];
end

-- Get ability ID by name
function M.GetAbilityId(abilityName)
    if not abilityName then return nil; end
    BuildAbilityLookup();
    return M.abilityNameToId[abilityName:lower()];
end

-- Clear caches (call on zone if needed)
function M.Clear()
    M.spellNameToId = nil;
    M.abilityNameToId = nil;
end

return M;
```

---

## Step 5: Update init.lua

Create primitives and fonts in the correct layer order.

### Add requires at top (after line 49)

```lua
local recast = require('modules.hotbar.recast');
```

### Modify Initialize() - Create primitives in order (after line 145)

Replace/expand the slot primitive creation section:

```lua
-- 2. Create slot primitives (render above background)
data.slotPrims[barIndex] = {};
for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
    local prim = primitives.new(primData);
    prim.visible = false;
    prim.can_focus = false;
    data.slotPrims[barIndex][slotIndex] = prim;
end

-- 3. Create icon primitives (render above slot backgrounds)
data.iconPrims[barIndex] = {};
for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
    local prim = primitives.new(primData);
    prim.visible = false;
    prim.can_focus = false;
    data.iconPrims[barIndex][slotIndex] = prim;
end

-- 4. Create cooldown overlay primitives (render above icons)
data.cooldownPrims[barIndex] = {};
for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
    local prim = primitives.new(primData);
    prim.visible = false;
    prim.can_focus = false;
    data.cooldownPrims[barIndex][slotIndex] = prim;
end
```

### Add timer font creation (after label fonts, around line 173)

```lua
-- 5. Create cooldown timer fonts (centered over slot)
data.timerFonts[barIndex] = {};
for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
    local timerSettings = deep_copy_table(fontSettings);
    timerSettings.font_height = 11;
    timerSettings.font_alignment = gdi.Alignment.Center;
    timerSettings.font_color = 0xFFFFFFFF;
    timerSettings.outline_color = 0xFF000000;
    timerSettings.outline_width = 2;
    local font = FontManager.create(timerSettings);
    font:set_visible(false);
    data.timerFonts[barIndex][slotIndex] = font;
    table.insert(data.allFonts, font);
end
```

### Update Cleanup() - Destroy new primitives/fonts (around line 397)

Add after slot primitive destruction:

```lua
-- Destroy icon primitives
if data.iconPrims[barIndex] then
    for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
        if data.iconPrims[barIndex][slotIndex] then
            data.iconPrims[barIndex][slotIndex]:destroy();
        end
    end
end

-- Destroy cooldown primitives
if data.cooldownPrims[barIndex] then
    for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
        if data.cooldownPrims[barIndex][slotIndex] then
            data.cooldownPrims[barIndex][slotIndex]:destroy();
        end
    end
end

-- Destroy timer fonts
if data.timerFonts[barIndex] then
    for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
        if data.timerFonts[barIndex][slotIndex] then
            FontManager.destroy(data.timerFonts[barIndex][slotIndex]);
        end
    end
end
```

---

## Step 6: Update display.lua

Replace ImGui icon rendering with primitives and add cooldown logic.

### Add requires at top (after line 17)

```lua
local recast = require('modules.hotbar.recast');
local actiondb = require('modules.hotbar.actiondb');
```

### Add asset path helper (after GetAssetsPath, around line 89)

```lua
-- Cooldown overlay texture path
local cooldownOverlayPath = nil;

local function GetCooldownOverlayPath()
    if not cooldownOverlayPath then
        cooldownOverlayPath = GetAssetsPath() .. 'cooldown-overlay.png';
    end
    return cooldownOverlayPath;
end
```

### Replace icon rendering in DrawSlot() (lines 180-206)

Remove the existing ImGui icon rendering and replace with:

```lua
-- Get primitives and fonts for this slot
local iconPrim = data.iconPrims[barIndex] and data.iconPrims[barIndex][slotIndex];
local cooldownPrim = data.cooldownPrims[barIndex] and data.cooldownPrims[barIndex][slotIndex];
local timerFont = data.timerFonts[barIndex] and data.timerFonts[barIndex][slotIndex];

-- Calculate icon positioning
local iconPadding = buttonSize * 0.125;
local iconSize = buttonSize * 0.75;
local iconX = x + iconPadding;
local iconY = y + iconPadding;

-- Get action IDs for recast lookup
local spellId = nil;
local abilityId = nil;
if bind then
    if bind.actionType == 'ma' then
        spellId = actiondb.GetSpellId(bind.action);
    elseif bind.actionType == 'ja' or bind.actionType == 'pet' then
        abilityId = actiondb.GetAbilityId(bind.action);
    end
end

-- Get recast state
local recastRemaining, recastText = 0, nil;
if bind then
    recastRemaining, recastText = recast.GetActionRecast(bind.actionType, spellId, abilityId);
end
local isOnCooldown = recastRemaining > 0;

-- Update icon primitive
if iconPrim then
    if spellIcon and spellIcon.path then
        iconPrim.texture = spellIcon.path;
        iconPrim.position_x = iconX;
        iconPrim.position_y = iconY;

        -- Scale texture to fit iconSize
        local textureSize = spellIcon.width or 40;
        local scale = iconSize / textureSize;
        iconPrim.scale_x = scale;
        iconPrim.scale_y = scale;

        -- Dim icon when on cooldown
        if isOnCooldown then
            iconPrim.color = 0xAAFFFFFF;  -- Slightly dimmed
        else
            iconPrim.color = 0xFFFFFFFF;  -- Full opacity
        end
        iconPrim.visible = true;
    else
        iconPrim.visible = false;
    end
end

-- Update cooldown overlay
if cooldownPrim then
    if isOnCooldown then
        cooldownPrim.texture = GetCooldownOverlayPath();
        cooldownPrim.position_x = iconX;
        cooldownPrim.position_y = iconY;

        local textureSize = 40;
        local scale = iconSize / textureSize;
        cooldownPrim.scale_x = scale;
        cooldownPrim.scale_y = scale;

        -- Semi-transparent dark overlay
        local overlayOpacity = 0.5;  -- 50% opacity
        local alpha = math.floor(overlayOpacity * 255);
        cooldownPrim.color = bit.bor(bit.lshift(alpha, 24), 0x000000);
        cooldownPrim.visible = true;
    else
        cooldownPrim.visible = false;
    end
end

-- Update timer text
if timerFont then
    if recastText then
        timerFont:set_text(recastText);
        -- Center in the icon area
        timerFont:set_position_x(iconX + iconSize / 2);
        timerFont:set_position_y(iconY + iconSize / 2 - 5);
        timerFont:set_visible(true);
    else
        timerFont:set_visible(false);
    end
end

-- Keep frame overlay rendering via ImGui (renders on top)
local drawList = imgui.GetWindowDrawList();
if drawList then
    -- Draw frame overlay if enabled
    if showSlotFrame then
        local frameTexture = textures:Get('frame');
        if frameTexture and frameTexture.image then
            local framePtr = tonumber(ffi.cast("uint32_t", frameTexture.image));
            if framePtr then
                drawList:AddImage(framePtr, {x, y}, {x + buttonSize, y + buttonSize});
            end
        end
    end

    -- Draw hover effect (still via ImGui for proper layering)
    if isHovered and not dragdrop.IsDragging() then
        local hoverTintColor = imgui.GetColorU32({1.0, 1.0, 1.0, 0.15});
        local hoverBorderColor = imgui.GetColorU32({1.0, 1.0, 1.0, 0.10});
        drawList:AddRectFilled({x, y}, {x + buttonSize, y + buttonSize}, hoverTintColor, 2);
        drawList:AddRect({x, y}, {x + buttonSize, y + buttonSize}, hoverBorderColor, 2, 0, 1);
    end
end
```

### Update DrawWindow() - Add recast update (at start of function, line 504)

```lua
function M.DrawWindow(settings)
    -- Update recast timers once per frame
    recast.Update();

    -- ... rest of existing code
```

### Update HideWindow() - Hide new elements (around line 545)

Add after existing slot primitive hiding:

```lua
-- Hide icon primitives
for barIndex = 1, data.NUM_BARS do
    if data.iconPrims[barIndex] then
        for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
            if data.iconPrims[barIndex][slotIndex] then
                data.iconPrims[barIndex][slotIndex].visible = false;
            end
        end
    end
end

-- Hide cooldown primitives
for barIndex = 1, data.NUM_BARS do
    if data.cooldownPrims[barIndex] then
        for slotIndex = 1, data.MAX_SLOTS_PER_BAR do
            if data.cooldownPrims[barIndex][slotIndex] then
                data.cooldownPrims[barIndex][slotIndex].visible = false;
            end
        end
    end
end
```

---

## Step 7: Update actions.lua

Ensure BuildCommand returns texture path.

### Modify BuildCommand return (ensure path is included)

The texture returned from `textures:Get()` now includes `.path`. Verify this is passed through:

```lua
-- When returning spell icon, ensure it has path
return command, spellIcon;  -- spellIcon now has .path property
```

---

## Step 8: Create Cooldown Overlay Asset

### File: assets/hotbar/cooldown-overlay.png

Create a 40x40 pixel image:
- Solid black (#000000) or very dark gray (#1a1a1a)
- The alpha will be controlled by primitive color

Can be created with any image editor or generated:
```
40x40 pixels, RGB(0,0,0), saved as PNG
```

---

## Configuration Options (Optional Enhancement)

Add to settings system later:

```lua
gConfig.hotbarGlobal.showCooldownOverlay = true;
gConfig.hotbarGlobal.showCooldownText = true;
gConfig.hotbarGlobal.cooldownOverlayOpacity = 0.5;
gConfig.hotbarGlobal.cooldownTextSize = 11;
```

---

## Testing Checklist

### Basic Functionality
- [ ] Icons render via primitives (not ImGui)
- [ ] Icons positioned correctly within slots
- [ ] Icons scale properly with slot size changes

### Cooldown Display
- [ ] Cast a spell, verify overlay appears
- [ ] Timer text shows and counts down
- [ ] Overlay disappears when cooldown ends
- [ ] Multiple slots can show cooldowns simultaneously

### Layer Order
- [ ] Icon is above slot background
- [ ] Overlay is above icon
- [ ] Timer text is above overlay
- [ ] Hover effect is above everything
- [ ] Tooltip renders correctly

### Performance
- [ ] No frame drops with 6 bars visible
- [ ] Recast update is throttled (not every frame)
- [ ] Action ID lookups are cached

### Edge Cases
- [ ] Empty slots don't show cooldown elements
- [ ] Slots with macros/equip don't crash
- [ ] Zone change doesn't break anything
- [ ] Job change updates correctly

---

## Implementation Order

1. Create `cooldown-overlay.png` asset
2. Update `textures.lua` to store paths
3. Update `data.lua` with new storage tables
4. Create `actiondb.lua` (name → ID lookup)
5. Create `recast.lua` (cooldown tracking)
6. Update `init.lua` (create primitives/fonts)
7. Update `display.lua` (render cooldowns)
8. Test with spells
9. Test with abilities
10. Polish and optimize
