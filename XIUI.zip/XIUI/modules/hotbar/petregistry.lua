--[[
* XIUI Hotbar - Pet Registry Module
* Centralized pet name-to-key mapping for pet-aware hotbar palettes
]]--

local M = {};

-- ============================================
-- Job Constants
-- ============================================

M.JOB_SMN = 15;
M.JOB_BST = 9;
M.JOB_DRG = 14;
M.JOB_PUP = 18;

-- ============================================
-- Pet Type Constants
-- ============================================

M.PET_TYPE_AVATAR = 'avatar';
M.PET_TYPE_SPIRIT = 'spirit';
M.PET_TYPE_WYVERN = 'wyvern';
M.PET_TYPE_AUTOMATON = 'automaton';
M.PET_TYPE_JUG = 'jug';
M.PET_TYPE_CHARM = 'charm';

-- ============================================
-- Avatar Mapping (petName -> storageKey)
-- ============================================

M.avatars = {
    ['Carbuncle'] = 'carbuncle',
    ['Ifrit'] = 'ifrit',
    ['Shiva'] = 'shiva',
    ['Garuda'] = 'garuda',
    ['Titan'] = 'titan',
    ['Ramuh'] = 'ramuh',
    ['Leviathan'] = 'leviathan',
    ['Fenrir'] = 'fenrir',
    ['Diabolos'] = 'diabolos',
    ['Atomos'] = 'atomos',
    ['Odin'] = 'odin',
    ['Alexander'] = 'alexander',
    ['Cait Sith'] = 'caitsith',
    ['Siren'] = 'siren',
};

-- ============================================
-- Spirit Mapping (petName -> storageKey)
-- ============================================

M.spirits = {
    ['Fire Spirit'] = 'firespirit',
    ['Ice Spirit'] = 'icespirit',
    ['Air Spirit'] = 'airspirit',
    ['Earth Spirit'] = 'earthspirit',
    ['Thunder Spirit'] = 'thunderspirit',
    ['Water Spirit'] = 'waterspirit',
    ['Light Spirit'] = 'lightspirit',
    ['Dark Spirit'] = 'darkspirit',
};

-- ============================================
-- Jug Pet Names (for BST)
-- Note: Jug pets share a common "jug" palette (too many for individual palettes)
-- ============================================

M.jugPets = {
    'FunguarFamiliar', 'CourierCarrie', 'SheepFamiliar', 'TigerFamiliar',
    'FlytrapFamiliar', 'LizardFamiliar', 'MayflyFamiliar', 'EftFamiliar',
    'BeetleFamiliar', 'AntlionFamiliar', 'MiteFamiliar', 'KeenearedSteffi',
    'LullabyMelodia', 'FlowerpotBen', 'FlowerpotBill', 'Homunculus',
    'VoraciousAudrey', 'AmbusherAllie', 'LifedrinkerLars', 'PanzerGalahad',
    'ChopsueyChucky', 'AmigoSabotender', 'CraftyClyvonne', 'BloodclawShasra',
    'GorefangHobs', 'DipperYuly', 'SunburstMalfik', 'WarlikePatrick',
    'ScissorlegXerin', 'BouncingBertha', 'RhymingShizuna', 'AttentiveIbuki',
    'SwoopingZhivago', 'GenerousArthur', 'ThreestarLynn', 'BrainyWaluis',
    'FaithfulFalcorr', 'SharpwitHermes', 'HeadbreakerKen', 'RedolentCandi',
    'AlluringHoney', 'CaringKiyomaro', 'VivaciousVickie', 'HurlerPercival',
    'BlackbeardRandy', 'FleetReinhard', 'GooeyGerard', 'CrudeRaphie',
    'DroopyDortwin', 'PonderingPeter', 'MosquitoFamilia', 'Left-HandedYoko',
};

-- Build lookup table for jug pets
M.jugPetLookup = {};
for _, petName in ipairs(M.jugPets) do
    M.jugPetLookup[petName] = true;
end

-- ============================================
-- Job Pet Categories
-- Maps job IDs to valid pet categories for that job
-- ============================================

M.jobPetCategories = {
    [M.JOB_SMN] = { M.PET_TYPE_AVATAR, M.PET_TYPE_SPIRIT },
    [M.JOB_DRG] = { M.PET_TYPE_WYVERN },
    [M.JOB_PUP] = { M.PET_TYPE_AUTOMATON },
    [M.JOB_BST] = { M.PET_TYPE_JUG, M.PET_TYPE_CHARM },
};

-- ============================================
-- Display Names for Pet Types
-- ============================================

M.petTypeDisplayNames = {
    [M.PET_TYPE_AVATAR] = 'Avatar',
    [M.PET_TYPE_SPIRIT] = 'Spirit',
    [M.PET_TYPE_WYVERN] = 'Wyvern',
    [M.PET_TYPE_AUTOMATON] = 'Automaton',
    [M.PET_TYPE_JUG] = 'Jug Pet',
    [M.PET_TYPE_CHARM] = 'Charmed',
};

-- ============================================
-- Functions
-- ============================================

-- Check if a job is a pet job
function M.IsPetJob(jobId)
    return M.jobPetCategories[jobId] ~= nil;
end

-- Get pet categories for a job
function M.GetPetCategories(jobId)
    return M.jobPetCategories[jobId] or {};
end

-- Check if a pet name is a jug pet
function M.IsJugPet(petName)
    if petName == nil then return false; end
    return M.jugPetLookup[petName] == true;
end

-- Check if a pet name is an avatar
function M.IsAvatar(petName)
    if petName == nil then return false; end
    return M.avatars[petName] ~= nil;
end

-- Check if a pet name is a spirit
function M.IsSpirit(petName)
    if petName == nil then return false; end
    return M.spirits[petName] ~= nil;
end

-- Get the pet type from a pet name and job
-- Returns: petType (string) or nil if unknown
function M.GetPetType(petName, jobId)
    if petName == nil then return nil; end

    -- Check by name first
    if M.avatars[petName] then
        return M.PET_TYPE_AVATAR;
    elseif M.spirits[petName] then
        return M.PET_TYPE_SPIRIT;
    elseif M.jugPetLookup[petName] then
        return M.PET_TYPE_JUG;
    elseif petName == 'Wyvern' or (jobId == M.JOB_DRG) then
        -- Wyvern can be renamed, so check job too
        return M.PET_TYPE_WYVERN;
    elseif jobId == M.JOB_PUP then
        return M.PET_TYPE_AUTOMATON;
    elseif jobId == M.JOB_BST then
        -- Unknown BST pet = charmed
        return M.PET_TYPE_CHARM;
    end

    return nil;
end

-- Get the storage key suffix for a pet
-- Returns: string like "avatar:ifrit", "wyvern", "jug", "automaton", etc.
-- For SMN avatars/spirits, returns per-entity keys
-- For other jobs, returns per-type keys
function M.GetPetKey(petName, jobId)
    if petName == nil then return nil; end

    local petType = M.GetPetType(petName, jobId);
    if not petType then return nil; end

    -- SMN: Per-avatar/spirit palettes
    if petType == M.PET_TYPE_AVATAR then
        local avatarKey = M.avatars[petName];
        if avatarKey then
            return M.PET_TYPE_AVATAR .. ':' .. avatarKey;
        end
    elseif petType == M.PET_TYPE_SPIRIT then
        local spiritKey = M.spirits[petName];
        if spiritKey then
            return M.PET_TYPE_SPIRIT .. ':' .. spiritKey;
        end
    end

    -- Other jobs: Per-type palettes (wyvern, automaton, jug, charm)
    return petType;
end

-- Get display name for a pet key
-- Input: "avatar:ifrit", "wyvern", etc.
-- Output: "Ifrit", "Wyvern", etc.
function M.GetDisplayNameForKey(petKey)
    if not petKey then return 'Base'; end

    -- Check for avatar/spirit format
    local petType, petId = petKey:match('^([^:]+):(.+)$');
    if petType and petId then
        if petType == M.PET_TYPE_AVATAR then
            -- Find avatar name
            for name, key in pairs(M.avatars) do
                if key == petId then return name; end
            end
        elseif petType == M.PET_TYPE_SPIRIT then
            -- Find spirit name
            for name, key in pairs(M.spirits) do
                if key == petId then return name; end
            end
        end
    end

    -- Check for simple type keys
    local displayName = M.petTypeDisplayNames[petKey];
    if displayName then return displayName; end

    return petKey;
end

-- Get all available pet keys for a job (for cycling)
-- Returns a table of pet keys that can be used for that job
function M.GetAvailablePetKeys(jobId)
    local keys = {};

    if jobId == M.JOB_SMN then
        -- All avatars
        for _, key in pairs(M.avatars) do
            table.insert(keys, M.PET_TYPE_AVATAR .. ':' .. key);
        end
        -- All spirits
        for _, key in pairs(M.spirits) do
            table.insert(keys, M.PET_TYPE_SPIRIT .. ':' .. key);
        end
    elseif jobId == M.JOB_DRG then
        table.insert(keys, M.PET_TYPE_WYVERN);
    elseif jobId == M.JOB_PUP then
        table.insert(keys, M.PET_TYPE_AUTOMATON);
    elseif jobId == M.JOB_BST then
        table.insert(keys, M.PET_TYPE_JUG);
        table.insert(keys, M.PET_TYPE_CHARM);
    end

    return keys;
end

-- Get ordered list of avatar names (for dropdowns, etc.)
function M.GetAvatarList()
    return {
        'Carbuncle', 'Ifrit', 'Shiva', 'Garuda', 'Titan', 'Ramuh',
        'Leviathan', 'Fenrir', 'Diabolos', 'Atomos', 'Odin', 'Alexander',
        'Cait Sith', 'Siren',
    };
end

-- Get ordered list of spirit names
function M.GetSpiritList()
    return {
        'Fire Spirit', 'Ice Spirit', 'Air Spirit', 'Earth Spirit',
        'Thunder Spirit', 'Water Spirit', 'Light Spirit', 'Dark Spirit',
    };
end

-- Get combined list of all summons (avatars + spirits)
function M.GetAllSummonsList()
    local list = {};
    -- Avatars first
    for _, avatar in ipairs(M.GetAvatarList()) do
        table.insert(list, { name = avatar, category = 'avatar' });
    end
    -- Then spirits
    for _, spirit in ipairs(M.GetSpiritList()) do
        table.insert(list, { name = spirit, category = 'spirit' });
    end
    return list;
end

-- Get the pet key for a summon name (avatar or spirit)
function M.GetPetKeyForSummon(summonName)
    -- Check avatars
    if M.avatars[summonName] then
        return 'avatar:' .. M.avatars[summonName];
    end
    -- Check spirits
    if M.spirits[summonName] then
        return 'spirit:' .. M.spirits[summonName];
    end
    return nil;
end

-- ============================================
-- Pet Commands Data
-- ============================================

-- Generic pet commands (all pet jobs)
M.genericPetCommands = {
    { name = 'Assault', category = 'Command' },
    { name = 'Retreat', category = 'Command' },
    { name = 'Stay', category = 'Command' },
    { name = 'Heel', category = 'Command' },
    { name = 'Release', category = 'Command' },
};

-- SMN Blood Pacts - Rage (offensive)
M.bloodPactsRage = {
    -- Shared
    { name = 'Punch', avatars = {'Ifrit', 'Titan', 'Carbuncle'} },
    { name = 'Fire II', avatars = {'Ifrit'} },
    { name = 'Burning Strike', avatars = {'Ifrit'} },
    { name = 'Double Punch', avatars = {'Ifrit', 'Titan'} },
    { name = 'Flaming Crush', avatars = {'Ifrit'} },
    { name = 'Meteor Strike', avatars = {'Ifrit'} },
    { name = 'Conflag Strike', avatars = {'Ifrit'} },
    { name = 'Fire IV', avatars = {'Ifrit'} },
    { name = 'Impact', avatars = {'Ifrit', 'Titan', 'Leviathan'} },
    -- Shiva
    { name = 'Axe Kick', avatars = {'Shiva'} },
    { name = 'Blizzard II', avatars = {'Shiva'} },
    { name = 'Double Slap', avatars = {'Shiva'} },
    { name = 'Blizzard IV', avatars = {'Shiva'} },
    { name = 'Rush', avatars = {'Shiva'} },
    { name = 'Heavenly Strike', avatars = {'Shiva'} },
    -- Garuda
    { name = 'Claw', avatars = {'Garuda', 'Fenrir'} },
    { name = 'Aero II', avatars = {'Garuda'} },
    { name = 'Aero IV', avatars = {'Garuda'} },
    { name = 'Predator Claws', avatars = {'Garuda'} },
    { name = 'Wind Blade', avatars = {'Garuda'} },
    -- Titan
    { name = 'Rock Throw', avatars = {'Titan'} },
    { name = 'Stone II', avatars = {'Titan'} },
    { name = 'Stone IV', avatars = {'Titan'} },
    { name = 'Rock Buster', avatars = {'Titan'} },
    { name = 'Megalith Throw', avatars = {'Titan'} },
    { name = 'Mountain Buster', avatars = {'Titan'} },
    { name = 'Geocrush', avatars = {'Titan'} },
    { name = 'Crag Throw', avatars = {'Titan'} },
    -- Ramuh
    { name = 'Shock Strike', avatars = {'Ramuh'} },
    { name = 'Thunder II', avatars = {'Ramuh'} },
    { name = 'Thunder IV', avatars = {'Ramuh'} },
    { name = 'Chaotic Strike', avatars = {'Ramuh'} },
    { name = 'Thunderstorm', avatars = {'Ramuh'} },
    { name = 'Thunderspark', avatars = {'Ramuh'} },
    { name = 'Volt Strike', avatars = {'Ramuh'} },
    -- Leviathan
    { name = 'Barracuda Dive', avatars = {'Leviathan'} },
    { name = 'Water II', avatars = {'Leviathan'} },
    { name = 'Water IV', avatars = {'Leviathan'} },
    { name = 'Tail Whip', avatars = {'Leviathan'} },
    { name = 'Spinning Dive', avatars = {'Leviathan'} },
    { name = 'Grand Fall', avatars = {'Leviathan'} },
    -- Fenrir
    { name = 'Moonlit Charge', avatars = {'Fenrir'} },
    { name = 'Crescent Fang', avatars = {'Fenrir'} },
    { name = 'Lunar Cry', avatars = {'Fenrir'} },
    { name = 'Lunar Roar', avatars = {'Fenrir'} },
    { name = 'Eclipse Bite', avatars = {'Fenrir'} },
    { name = 'Howling Moon', avatars = {'Fenrir'} },
    { name = 'Impact', avatars = {'Fenrir'} },
    -- Diabolos
    { name = 'Camisado', avatars = {'Diabolos'} },
    { name = 'Somnolence', avatars = {'Diabolos'} },
    { name = 'Nightmare', avatars = {'Diabolos'} },
    { name = 'Ultimate Terror', avatars = {'Diabolos'} },
    { name = 'Noctoshield', avatars = {'Diabolos'} },
    { name = 'Dream Shroud', avatars = {'Diabolos'} },
    { name = 'Nether Blast', avatars = {'Diabolos'} },
    { name = 'Night Terror', avatars = {'Diabolos'} },
    -- Carbuncle
    { name = 'Poison Nails', avatars = {'Carbuncle'} },
    { name = 'Holy Mist', avatars = {'Carbuncle'} },
    { name = 'Meteorite', avatars = {'Carbuncle'} },
    -- Atomos
    { name = 'Crobat Pummel', avatars = {'Atomos'} },
    { name = 'Chronoshift', avatars = {'Atomos'} },
    -- Odin
    { name = 'Zantetsuken', avatars = {'Odin'} },
    -- Alexander
    { name = 'Perfect Defense', avatars = {'Alexander'} },
    -- Cait Sith
    { name = 'Regal Scratch', avatars = {'Cait Sith'} },
    { name = 'Level ? Holy', avatars = {'Cait Sith'} },
    { name = 'Regal Gash', avatars = {'Cait Sith'} },
    -- Siren
    { name = 'Clarsach Call', avatars = {'Siren'} },
    { name = 'Sonic Buffet', avatars = {'Siren'} },
    { name = 'Tornado II', avatars = {'Siren'} },
    { name = 'Hysteric Assault', avatars = {'Siren'} },
};

-- SMN Blood Pacts - Ward (support)
M.bloodPactsWard = {
    -- Carbuncle
    { name = 'Soothing Ruby', avatars = {'Carbuncle'} },
    { name = 'Healing Ruby', avatars = {'Carbuncle'} },
    { name = 'Shining Ruby', avatars = {'Carbuncle'} },
    { name = 'Glittering Ruby', avatars = {'Carbuncle'} },
    { name = 'Healing Ruby II', avatars = {'Carbuncle'} },
    { name = 'Pacifying Ruby', avatars = {'Carbuncle'} },
    -- Ifrit
    { name = 'Crimson Howl', avatars = {'Ifrit'} },
    { name = 'Inferno Howl', avatars = {'Ifrit'} },
    -- Shiva
    { name = 'Frost Armor', avatars = {'Shiva'} },
    { name = 'Sleepga', avatars = {'Shiva'} },
    { name = 'Diamond Storm', avatars = {'Shiva'} },
    { name = 'Crystal Blessing', avatars = {'Shiva'} },
    -- Garuda
    { name = 'Aerial Armor', avatars = {'Garuda'} },
    { name = 'Whispering Wind', avatars = {'Garuda'} },
    { name = 'Hastega', avatars = {'Garuda'} },
    { name = 'Fleet Wind', avatars = {'Garuda'} },
    -- Titan
    { name = 'Earthen Ward', avatars = {'Titan'} },
    { name = 'Earthen Armor', avatars = {'Titan'} },
    -- Ramuh
    { name = 'Rolling Thunder', avatars = {'Ramuh'} },
    { name = 'Lightning Armor', avatars = {'Ramuh'} },
    { name = 'Shock Squall', avatars = {'Ramuh'} },
    -- Leviathan
    { name = 'Slowga', avatars = {'Leviathan'} },
    { name = 'Spring Water', avatars = {'Leviathan'} },
    { name = 'Tidal Roar', avatars = {'Leviathan'} },
    -- Fenrir
    { name = 'Ecliptic Growl', avatars = {'Fenrir'} },
    { name = 'Ecliptic Howl', avatars = {'Fenrir'} },
    -- Diabolos
    { name = 'Pavor Nocturnus', avatars = {'Diabolos'} },
    -- Cait Sith
    { name = 'Mewing Lullaby', avatars = {'Cait Sith'} },
    { name = 'Eerie Eye', avatars = {'Cait Sith'} },
    { name = 'Altana\'s Favor', avatars = {'Cait Sith'} },
    { name = 'Raise II', avatars = {'Cait Sith'} },
    { name = 'Reraise II', avatars = {'Cait Sith'} },
    -- Siren
    { name = 'Lunatic Voice', avatars = {'Siren'} },
    { name = 'Chinook', avatars = {'Siren'} },
    { name = 'Bitter Elegy', avatars = {'Siren'} },
    { name = 'Welt', avatars = {'Siren'} },
    { name = 'Katabatic Blades', avatars = {'Siren'} },
};

-- DRG Wyvern abilities
M.wyvernCommands = {
    { name = 'Spirit Link', category = 'Ability' },
    { name = 'Steady Wing', category = 'Ability' },
    { name = 'Spirit Bond', category = 'Ability' },
    { name = 'Dragon Breaker', category = 'Ability' },
    { name = 'Spirit Jump', category = 'Ability' },
    { name = 'Soul Jump', category = 'Ability' },
};

-- PUP Automaton commands
M.automatonCommands = {
    { name = 'Deploy', category = 'Command' },
    { name = 'Retrieve', category = 'Command' },
    { name = 'Activate', category = 'Ability' },
    { name = 'Deactivate', category = 'Ability' },
    { name = 'Deus Ex Automata', category = 'Ability' },
    { name = 'Repair', category = 'Ability' },
    { name = 'Maintenance', category = 'Ability' },
    { name = 'Role Reversal', category = 'Ability' },
    { name = 'Ventriloquy', category = 'Ability' },
    { name = 'Cooldown', category = 'Ability' },
    { name = 'Overdrive', category = 'Ability' },
    { name = 'Tactical Switch', category = 'Ability' },
    { name = 'Heady Artifice', category = 'Ability' },
};

-- BST Ready abilities (Sic commands)
M.bstReadyCommands = {
    { name = 'Sic', category = 'Command' },
    { name = 'Ready', category = 'Command' },
    { name = 'Reward', category = 'Ability' },
    { name = 'Call Beast', category = 'Ability' },
    { name = 'Bestial Loyalty', category = 'Ability' },
    { name = 'Familiar', category = 'Ability' },
    { name = 'Feral Howl', category = 'Ability' },
    { name = 'Killer Instinct', category = 'Ability' },
    { name = 'Spur', category = 'Ability' },
    { name = 'Run Wild', category = 'Ability' },
    { name = 'Unleash', category = 'Ability' },
};

-- ============================================
-- Pet Command Functions
-- ============================================

-- Get blood pacts for a specific avatar (both Rage and Ward)
function M.GetBloodPactsForAvatar(avatarName)
    local pacts = {};

    -- Add Rage pacts
    for _, pact in ipairs(M.bloodPactsRage) do
        for _, avatar in ipairs(pact.avatars) do
            if avatar == avatarName then
                table.insert(pacts, { name = pact.name, category = 'BP: Rage' });
                break;
            end
        end
    end

    -- Add Ward pacts
    for _, pact in ipairs(M.bloodPactsWard) do
        for _, avatar in ipairs(pact.avatars) do
            if avatar == avatarName then
                table.insert(pacts, { name = pact.name, category = 'BP: Ward' });
                break;
            end
        end
    end

    return pacts;
end

-- Get all blood pacts (for when no specific avatar selected)
function M.GetAllBloodPacts()
    local pacts = {};
    local seen = {};

    -- Add all Rage pacts
    for _, pact in ipairs(M.bloodPactsRage) do
        if not seen[pact.name] then
            table.insert(pacts, { name = pact.name, category = 'BP: Rage' });
            seen[pact.name] = true;
        end
    end

    -- Add all Ward pacts
    for _, pact in ipairs(M.bloodPactsWard) do
        if not seen[pact.name] then
            table.insert(pacts, { name = pact.name, category = 'BP: Ward' });
            seen[pact.name] = true;
        end
    end

    return pacts;
end

-- Get pet commands for a specific job
-- avatarName is optional, for SMN to filter by specific avatar
function M.GetPetCommandsForJob(jobId, avatarName)
    local commands = {};

    -- Add generic commands first
    for _, cmd in ipairs(M.genericPetCommands) do
        table.insert(commands, { name = cmd.name, category = cmd.category });
    end

    if jobId == M.JOB_SMN then
        -- SMN: Blood Pacts
        if avatarName and M.avatars[avatarName] then
            -- Specific avatar - add only their pacts
            local avatarPacts = M.GetBloodPactsForAvatar(avatarName);
            for _, pact in ipairs(avatarPacts) do
                table.insert(commands, pact);
            end
        else
            -- No specific avatar - add all pacts
            local allPacts = M.GetAllBloodPacts();
            for _, pact in ipairs(allPacts) do
                table.insert(commands, pact);
            end
        end
    elseif jobId == M.JOB_DRG then
        -- DRG: Wyvern commands
        for _, cmd in ipairs(M.wyvernCommands) do
            table.insert(commands, { name = cmd.name, category = cmd.category });
        end
    elseif jobId == M.JOB_PUP then
        -- PUP: Automaton commands
        for _, cmd in ipairs(M.automatonCommands) do
            table.insert(commands, { name = cmd.name, category = cmd.category });
        end
    elseif jobId == M.JOB_BST then
        -- BST: Ready commands
        for _, cmd in ipairs(M.bstReadyCommands) do
            table.insert(commands, { name = cmd.name, category = cmd.category });
        end
    end

    return commands;
end

return M;
