--Zone: Dynamis - Bastok [D]
--Zone ID: 295
return {
    Names = {
    },
    Indices = {
    },
};