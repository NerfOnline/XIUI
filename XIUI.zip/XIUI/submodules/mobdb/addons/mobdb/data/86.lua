--Zone: Everbloom Hollow
--Zone ID: 86
return {
    Names = {
    },
    Indices = {
    },
};